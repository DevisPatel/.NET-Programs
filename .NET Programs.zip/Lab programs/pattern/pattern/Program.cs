﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pattern
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                int  i,j,n;

                Console.WriteLine("\n Enter value \n");
                n = Convert.ToInt32(Console.ReadLine());
                for (i = 1; i <= n; i++)
                {
                    for (j = 1; j <= 5; j++)
                    {
                        if (n%4==0)
                        {
                            Console.Write(" *");
                        }
                    }
                    Console.WriteLine(" \n \n");
                }
                
            }
        }
    }
}
