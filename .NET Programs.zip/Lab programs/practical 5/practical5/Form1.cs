﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace practical5
{
    public partial class Form1 : Form
    {

        SqlConnection c;
        SqlCommand d;
        SqlDataAdapter a;
        int i = 0;
        DataSet ds;
        //public string s;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            string s;
            c = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\user\\Documents\\vier.mdf;Integrated Security=True;Connect Timeout=30");
            c.Open();
            s = "select * from student";
            d = new SqlCommand(s, c);

             ds = new DataSet();
            a = new SqlDataAdapter(d);
            a.Fill(ds, "student");
            dataGridView1.DataSource = ds.Tables["student"];

            i = d.ExecuteNonQuery();
            if (i > 0)
            {
                MessageBox.Show("Table Loaded Successfully");
            }
            else
            {
                MessageBox.Show("Table Not Loaded Successfully");
            }
            c.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s;
            c = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\user\\Documents\\vier.mdf;Integrated Security=True;Connect Timeout=30");
            c.Open();
            s = "insert into student(Roll_No,Name,Address) values ("+textBox1.Text+",'"+textBox2.Text+"','" + textBox3.Text + "')";
            d = new SqlCommand( s, c);
            i = d.ExecuteNonQuery();
            if(i>0)
            {
                MessageBox.Show("Property Inserted Successfully");
            }
            else
            {
                MessageBox.Show("Property Not Inserted Successfully");
            }
            c.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s;
            c = new SqlConnection("Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\user\\Documents\\vier.mdf; Integrated Security = True; Connect Timeout = 30");
            c.Open();
            s = "delete from student where Roll_No = " + textBox1.Text + "";
            d = new SqlCommand(s, c);
            i = d.ExecuteNonQuery();
            if (i > 0)
            {
                MessageBox.Show("Property Deleted Successfully");
            }
            else
            {
                MessageBox.Show("Property Not Deleted Successfully");
            }
            c.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s;
            c = new SqlConnection("Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\user\\Documents\\vier.mdf; Integrated Security = True; Connect Timeout = 30");
            c.Open();

            s = "update student set Name='"+textBox2.Text+"',Address='"+ textBox3.Text + "' where (Roll_No="+ textBox1.Text +") ";
            d = new SqlCommand(s,c);
            i = d.ExecuteNonQuery();
            if (i > 0)
            {
                MessageBox.Show("Property Updated Successfully");
            }
            else
            {
                MessageBox.Show("Property Not Updated Successfully");
            }
            c.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            i = i + 1;
            if (i < (ds.Tables["student"].Rows.Count))
            {
                textBox1.Text = ds.Tables["student"].Rows[i][0].ToString();
                textBox2.Text = ds.Tables["student"].Rows[i][1].ToString();
                textBox3.Text = ds.Tables["student"].Rows[i][2].ToString();
            }

            else
            {
                MessageBox.Show("No Row Updated");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {

            i = i - 1;
            if (i>=0)
            {
                textBox1.Text = ds.Tables["student"].Rows[i][0].ToString();
                textBox2.Text = ds.Tables["student"].Rows[i][1].ToString();
                textBox3.Text = ds.Tables["student"].Rows[i][2].ToString();
            }

            else
            {
                MessageBox.Show("No Row Updated");
            }
        }
    }
}
