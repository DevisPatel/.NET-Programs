﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        TextBox3.Text = "";
        TextBox4.Text = "";

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        SqlConnection cn;
        SqlCommand cd;
        SqlDataAdapter ad;

        cn = new SqlConnection("Data Source=(LocalDB)\\sv11.0;AttachDbFilename="C:\\Users\\ARPAN PATEL\\Documents\\login.mdf";Integrated Security=True;Connect Timeout=30");
        cn.Open();
        cd=new SqlCommand("select * from login whare (uname='"+TextBox3.Text +"' and password='"+ TextBox4.Text+"')",cn);
        ad=new SqlDataAdapter(cd);
        DataSet ds =new DataSet();
        ad.Fill(ds);

        if(ds.Tables[0].Rows.Count>0)
        {
            Response.Redirect("Default2.aspx");
        }

        else
        {
            Label2.Text=" You have Entered wrong password";
        }
        cn.Close();

    }
}