﻿using System;

namespace prg1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int fgg = 0;
            double r,d,u,f;
           
        Devis:

            if (fgg == 0)
            {
                fgg = 1;
                Console.WriteLine("\n Enter Your Choice \n 1. Convert Rupees into Dollar \n 2. Convert Rupees into Euro \n 3. Convert Rupees into Frank \n 4. Exit \n");
                a = Convert.ToInt32(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        {
                            Console.WriteLine("\n Enter Rupees to Convert into Dollar \n");
                            r = Convert.ToDouble(Console.ReadLine());
                            d = r/68;
                            Console.WriteLine("\n Value of Given Rupees in Dollar is = {0} " , d);
                            break;
                        }

                    case 2:
                        {
                            Console.WriteLine("\n Enter Rupees to Convert into Euro \n");
                            r = Convert.ToDouble(Console.ReadLine());
                            u = r / 88;
                            Console.WriteLine("\n Value of Given Rupees in Euro is = {0} " , u);
                            break;
                        }

                    case 3:
                        {
                            Console.WriteLine("\n Enter Rupees to Convert into Frank \n");
                            r = Convert.ToDouble(Console.ReadLine());
                            f = r / 72;
                            Console.WriteLine("\n Value of Given Rupees in Frank is = {0} " , f);
                            break;
                        }

                    case 4:
                        {
                            Environment.Exit(0);
                            break;
                        }

                }
            }
            fgg = 0;
            if (fgg == 0)
            {
                goto Devis;
            }
        }

    }
}
