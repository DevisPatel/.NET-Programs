﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace practical6
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter ada;
        DataSet ds;
        DataSet ds1;
        SqlDataReader dr;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con= new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\user\\Documents\\vier.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            cmd =new SqlCommand("select * from state",con);
            ada=new SqlDataAdapter(cmd);
            ds=new DataSet();
            ada.Fill(ds);
            con.Close();
            comboBox1.DataSource=ds.Tables[0];
            comboBox1.DisplayMember="statename";
            comboBox1.ValueMember="statecode";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\user\\Documents\\vier.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            cmd = new SqlCommand("select * from Stu", con);
            ada = new SqlDataAdapter(cmd);
            ds = new DataSet();
            ada.Fill(ds);

            ds.WriteXml("E:\\Programs\\Sem 6\\.NET practicals\\Lab programs\\practical6\\devis.xml");
            webBrowser1.Url = new Uri("E:\\Programs\\Sem 6\\.NET practicals\\Lab programs\\practical6\\devis.xml");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ds1 = new DataSet();
            ds1.ReadXml("E:\\Programs\\Sem 6\\.NET practicals\\Lab programs\\practical6\\devis.xml");
            dataGridView1.DataSource = ds1.Tables[0];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int i;
            con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\user\\Documents\\vier.mdf;Integrated Security=True;Connect Timeout=30"); con.Open();
            cmd = new SqlCommand("insert into Stu(stuname,statename,cityname) values ('"+textBox1.Text+"','"+comboBox1.SelectedValue.ToString()+"','"+comboBox2.SelectedValue.ToString()+"')",con);
                i=cmd.ExecuteNonQuery();
            if(i>0)
            {
                MessageBox.Show("Property Inserted successfully");
            }
            else
            {
                MessageBox.Show("Error in Insert command");
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\user\\Documents\\vier.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            cmd = new SqlCommand("select * from Stu",con);
            dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                ListBox1.Items.Add(dr.GetValue(0)+"  "+dr.GetValue(1)+"  "+dr.GetValue(2));
            }
            con.Close();
            dr.Close();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue.ToString() != "System.Data.DataRowView")
            {
                con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\user\\Documents\\vier.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();
                cmd = new SqlCommand("select * from city where statecode='"+comboBox1.SelectedValue.ToString()+"'", con);
                ada = new SqlDataAdapter(cmd);
                ds = new DataSet();
                ada.Fill(ds);
                con.Close();
                comboBox2.DataSource = ds.Tables[0];
                comboBox2.DisplayMember = "cityname";
                comboBox2.ValueMember = "cityname";        
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
