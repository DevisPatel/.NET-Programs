﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        double rate, qlty, stotal, total, tax, vat, disc, disamt, ftotal;
        String str;
        String[] str1;
        public Form1()
        {
             
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loadcity();
            loaditem();
        }

        public void loadcity()
            {
                comboBox1.Items.Add("Vadodara");
                comboBox1.Items.Add("Ahemdabad");
                comboBox1.Items.Add("Surat");
                comboBox1.Items.Add("Vapi");
                comboBox1.Items.Add("Mumbai");
                comboBox1.Items.Add("Delhi");
        }
        public void loaditem()
        {
            comboBox2.Items.Add("Pizza");
            comboBox2.Items.Add("Dhosa");
            comboBox2.Items.Add("Burger");
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox3.Text = "0";
            textBox4.Text = "0";
            textBox5.Text = "0";

            if(comboBox2.SelectedItem=="Pizza")
            {
                rate = 120;
             pictureBox1.Image=Image.FromFile("E:\\Programs\\12.jpg");
            }
            else if(comboBox2.SelectedItem=="Dhosa")
            {
                rate = 60;
                pictureBox1.Image = Image.FromFile("E:\\Programs\\13.jpg");

            }
            else if(comboBox2.SelectedItem=="Burger")
            {
                rate = 100;
                pictureBox1.Image = Image.FromFile("E:\\Programs\\15.png");
            }
            textBox3.Text = rate.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox4.Text=="0")
            {
                MessageBox.Show("Invalid");
            }
            else
            {
                stotal = rate * (double.Parse(textBox4.Text));
                total = total + stotal;
                textBox5.Text = stotal.ToString();
                textBox6.Text = total.ToString();

            }
            str = "Item:" + comboBox2.SelectedItem.ToString() + "  rate :" + rate.ToString() + "  qnty :" + textBox4.Text + "  subtotal :" + stotal.ToString();
            listBox1.Items.Add(str);
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(radioButton3.Checked==true)
            {
                disc = 10.0;
                textBox9.Text = disc.ToString();

            }
            else
            {
                disc = 0.0;
                textBox9.Text = disc.ToString();
            }

            if(comboBox2.SelectedItem=="Pizza")
            {
                tax = 5.0;
                vat = 2.0;
                disamt = (disc * rate) / 100.0;
                ftotal = total + tax + vat - disamt;
                textBox7.Text = tax.ToString();
                textBox8.Text = vat.ToString();
                textBox10.Text = disamt.ToString();
                textBox11.Text = ftotal.ToString();

            }
            else if (comboBox2.SelectedItem == "Dhosa")
            {
                tax = 3.0;
                vat = 1.7;
                disamt = (disc * rate) / 100.0;
                ftotal = total + tax + vat - disamt;
                textBox7.Text = tax.ToString();
                textBox8.Text = vat.ToString();
                textBox10.Text = disamt.ToString();
                textBox11.Text = ftotal.ToString();

            }
            else if(comboBox2.SelectedItem=="Burger")
            {
                tax = 2.0;
                vat = 1.5;
                disamt = (disc * rate) / 100.0;
                ftotal = total + tax + vat - disamt;
                textBox7.Text = tax.ToString();
                textBox8.Text = vat.ToString();
                textBox10.Text = disamt.ToString();
                textBox11.Text = ftotal.ToString();

            }

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.Text =="")
            {
                MessageBox.Show("empty");

            }
            else
            {
                str = listBox1.SelectedItem.ToString();
                str1 = str.Split(':');
                stotal = double.Parse(str1[4]);
                total = total - stotal;
            
                textBox6.Text = total.ToString();
                listBox1.Items.Remove(str);
            }
        }
    }
}