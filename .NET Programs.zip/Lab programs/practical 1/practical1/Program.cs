﻿using System;

namespace prg1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int fgg = 0;
            double c, f, t, x;
          
        Devis:

            if (fgg == 0)
            {
                fgg = 1;
                Console.WriteLine("\n Enter Your Choice \n 1. C to F \n 2. F to C \n 3. Exit \n");
                a = Convert.ToInt32(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        {
                            Console.WriteLine("\n Enter Temperature in Celsius   \n");
                            c = Convert.ToDouble(Console.ReadLine());
                            f = (c * (1.8));
                            t = f + 32;
                            t = 0 + t;
                            Console.WriteLine("\n Temperature in Fahrenheit is   " + t);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("\n Enter Temperature in Fahrenheit \n");
                            f = Convert.ToDouble(Console.ReadLine());
                            c = (f - 32);
                            x = c / (1.8);
                            x = 0 + x;
                            Console.WriteLine("\n Temperature in  is Celsius is   " + x);
                            break;
                        }

                    case 3:
                        {
                            Environment.Exit(0);
                            break;
                        }

                }
            }
            fgg = 0;
            if (fgg == 0)
            {
                goto Devis;
            }
        }

    }
}
