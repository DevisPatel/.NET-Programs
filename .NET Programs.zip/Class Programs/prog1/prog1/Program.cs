﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog1
{

    class A
    {
        public int r,l,b,d;
        public double a1, a2, a3;

        public void circle()
        {

            Console.WriteLine("\n Enter Radius of The Circle \n");
            r = Convert.ToInt32(Console.ReadLine());
            a1 = (3.14 * r * r);
            Console.WriteLine("\n Area of the cicle is   " + a1);
        }

        public void rect()
        {

            Console.WriteLine("\n Enter Length of The Rectangle \n");
            l = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n Enter Breath of The Rectangle \n");
            b = Convert.ToInt32(Console.ReadLine());
            a2 = (2 * l * b);
            Console.WriteLine("\n Area of the rectangle is   " + a2);
        }

        public void sqre()
        {
            
            Console.WriteLine("\n Enter Length of The Square \n");
            d = Convert.ToInt32(Console.ReadLine());
            a3 = (2*d);
            Console.WriteLine("\n Area of the square is   " + a3);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int c;
            int flag = 0;
            A a = new A();

    devis:
            Console.WriteLine("\n enter your choice \n 1.Area of Circle \n 2.Area of Rectangle \n 3.Area of Square \n 4.exit \n");
            c = Convert.ToInt32(Console.ReadLine());
   
            if (flag == 0)
            {
                flag = 1;
                if (c == 1)
                {
                    a.circle();

                }

                else if (c == 2)
                {
                    a.rect();
                }

                else if (c == 3)
                {
                    a.sqre();
                }

                else if (c == 4)
                {
                    Environment.Exit(0);
                }

                else
                {
                    Console.WriteLine("\n The Choice You Have Entered is Invalid \n");
                }

                Console.WriteLine("\n ..... \n \n \n .........\n..........\n.......\n... ................... Haaruu.....AAve ENTER Press Karine... .....Get Lost Thai JAAAAAAA.......\n .........."+flag);
            }
            flag = 0;
            if(flag==0)
            {
                goto devis;
            }
        }
    }
  }
