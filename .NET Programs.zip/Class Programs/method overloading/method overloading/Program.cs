﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace method_overloading
{

    class M
    {
        public double area(double r)
        {
            double x;
            Console.WriteLine("\n Enter Radius of Circle \n");
            r = Convert.ToDouble(Console.ReadLine());
            x = (3.14 * r * r);
            return x;
        }

        public double area(double l, double b)
        {
            double y;
            Console.WriteLine("\n Enter Length of Rectangle \n");
            l = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("\n Enter Breath of Rectangle \n");
            b = Convert.ToDouble(Console.ReadLine());
            y = l * b;
            return y;
        }

        public int area(int d)
        {
            int z;
            Console.WriteLine("\n Enter Side of Square \n");
            d = Convert.ToInt32(Console.ReadLine());
            z = d * d;
            return z;
        }

    }

    class Program
    {
        static void Main(string[] args)
        {

            int c;
            M a = new M();

            Console.WriteLine("\n Enter your choice \n  1. Area of Circle \n  2. Area of Rectangle \n  3. Area of Square \n  4. Exit \n");
            c = Convert.ToInt32(Console.ReadLine());

            if (c == 1)
            {
                Console.WriteLine("\n Area of Circle is =  "+ a.area(1.2));  
            }

            else if (c == 2)
            {
                Console.WriteLine("\n Area of Rectangle is =  " + a.area(1.2,1.6));
            }

            else if (c == 3)
            {
                Console.WriteLine("\n Area of Square is =  " + a.area(1));
            }

            else if(c==4)
            {
                Environment.Exit(0);
            }
}
    }
}
