﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Const_Inheritence
{
    public class A
    {
        public A()
        {
            Console.WriteLine("\n Base Class Default Constructor is called \n");
        }
        
        public void show()
        {
            Console.WriteLine("\n Base Class Method is called \n");
        } 
    }

    public class B : A
    {
        public B()
        {
            Console.WriteLine("\n Derived Class Default Constructor is called \n");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            B i = new B();
            i.show();
        }
    }
}
